import { Form, button, Container, Table, Row, Col, Button, Modal, FormText } from 'react-bootstrap';
import { json, useParams } from "react-router-dom";
import 'bootstrap/dist/css/bootstrap.min.css';
import { useEffect, useState } from "react";
import GNB from "./GlobalNavigationBar";

export default function MyBoardDetail() {
    const [article, setArticle] = useState({});
    const [comments, setComments] = useState([]);
    const { id } = useParams();

    const backendDomain = "http://localhost:3030"
    useEffect(() => {
        const articleRequestUrl = `${backendDomain}/boards/${id}`

        fetch(articleRequestUrl)
            .then(response => response.json())
            .then(json => {
                setArticle(json);
            })

        const commentRequestUrl = `${backendDomain}/replies?board_id=${id}`
        fetch(commentRequestUrl)
            .then(response => response.json())
            .then(json => { setComments(json); console.log(json) });

    }, [id]);

    return (
        <>
            <GNB />
            <Container>
                <Article />
                <CommentForm />
                <Comment />
            </Container>
        </>
    )

    function Article() {
        return (
            <Container className="articleZone">
                <Table bordered className='table-sm table'>
                    <tbody>
                        <tr className="row pd-0 mx-0">
                            <td className="col-1">작성자</td>
                            <td className="col-2" id="articleAuthor">{article.mem_id}</td>
                            <td className="col-1">작성일자</td>
                            <td className="col-2" id="articleCreatedAt">{article.reg_dtm}</td>
                            <td className="col-1">수정일자</td>
                            <td className="col-2" id="articleUpdatedAt">{article.mod_dtm}</td>
                            <td className="col-1">조회수</td>
                            <td className="col-2" id="articleViewCount">{article.count}</td>
                        </tr>
                        <tr className="row pd-0 mx-0">
                            <td className="col-1">제목</td>
                            <td colSpan={5} className="col-11" id="articleTitle">{article.title}</td>
                        </tr>
                        <tr className="row pd-0 mx-0">
                            <td className="col-1">내용</td>
                            <td colSpan={5} className="col-11" id="articleContent">{article.text}</td>
                        </tr>
                    </tbody>
                </Table>
                <Button variant='primary' onClick={moveToEditArticle}>글 수정하기</Button>
                <Button variant='danger' onClick={deleteArticle}>글 삭제하기</Button>
            </Container>
        )
    }

    function deleteArticle() {
        const deleteArticleRequestUrl = `${backendDomain}/boards`;
        fetch(`${deleteArticleRequestUrl}/${id}`, {
            method: "DELETE"
        }).then((response) => response.json())
            .then((result) => alert('게시글 삭제 완료!'))
    }

    function moveToEditArticle() {

    }

    function Comment() {
        return (
            <>
                {comments.map(comment => (
                    <Container>
                        <span>
                            <button className="btn btn-sm btn-primary">수정</button>
                            <button className="btn btn-sm btn-danger">삭제</button>
                        </span>
                        <Table className="table table-bordered view">
                            <tbody>
                                <tr className="row pd-0 mx-0">
                                    <td className="col-1">작성자</td>
                                    <td className="col-9">{comment.mem_id}</td>
                                    <td className="col-2">{comment.reg_dtm}</td>
                                </tr>
                                <tr className="row pd-0 mx-0">
                                    <td className="col-1">내용</td>
                                    <td className="col-11" colSpan={2}>{comment.reply}</td>
                                </tr>
                            </tbody>
                        </Table>
                    </Container>
                ))}
            </>
        )
    }

    function CommentForm() {
        return (
            <Container>
                <form action="">
                    <div className="form-row">
                        <div className="form-group col-md-6">
                            <label htmlFor="userNameInput">Name</label>
                            <input
                                type="text"
                                className="form-control"
                                id="userNameInput"
                                name="nameInput"
                                placeholder="닉네임을 입력하세요"
                            />
                        </div>
                        <div className="form-group col-md-6">
                            <label>Password(댓글 수정/삭제 시 필요)</label>
                            <input
                                type="password"
                                className="form-control"
                                id="commentPWinput"
                                name="commentPWinput"
                                placeholder="비밀번호를 설정해주세요"
                            />
                        </div>
                    </div>
                    <div className="form-group">
                        <label htmlFor="contentInput">Content</label>
                        <textarea
                            className="form-control"
                            id="contentInput"
                            name="contentInput"
                            placeholder="내용을 입력하세요"
                            rows={2}
                            defaultValue={""}
                        />
                    </div>
                    <div style={{ visibility: "hidden" }}>
                        <input
                            type="text"
                            className="form-control"
                            name="articleNum"
                            defaultValue="<?php echo $num; ?>"
                        />
                    </div>
                    <button type="submit" className="btn btn-primary">
                        Submit
                    </button>
                </form>
            </Container>
        )
    }

    function insertComment() {
        const insertCommentRequestUrl = `${backendDomain}/replies`;
        let now = new Date().toString();
        let bodyString = JSON.stringify({
            board_id: id,
            mem_id: "lorem",
            reply: "...",
            reg_dtm: now
        });

        fetch(insertCommentRequestUrl, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: bodyString
        })
            .then((response) => response.json())
            .then((result) => {
                alert('댓글이 등록되었습니다');
            })
    }

    function deleteComment() {

    }

    function editComment() {

    }
}