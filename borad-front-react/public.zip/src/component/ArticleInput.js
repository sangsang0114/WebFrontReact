import { Link } from "react-router-dom";
import GNB from "./GlobalNavigationBar";
import { useEffect, useState, useRef } from "react";
import { Form, button, Container, Table, Row, Col, Button, CardBody } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';

export default function MyBoardInsert() {
    const nicknameRef = useRef(null);
    const titleRef = useRef(null);
    const contentRef = useRef(null);

    function addArticle(event) {
        event.preventDefault();  //이벤트의 기본 핸들러 동작 못하게 함. 

        const backEndDomain = "http://localhost:3030";
        const requestUrl = `${backEndDomain}/boards/`;
        let now = new Date().toString();
        let bodyString = JSON.stringify({
            mem_id: nicknameRef.current.value,
            title: titleRef.current.value,
            text: contentRef.current.value,
            count: 1,
            red_dtm: now,
            mod_dtm: now,
        });
        fetch(requestUrl,
            {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: bodyString
            }
        )
            .then((response) => response.json())
            .then((result) => {
                alert('done');
            });
    }
    return (
        <>
            <GNB />
            <Form action="" id="insertForm">
                <div className="container">
                    <div className="form-group">
                    </div>
                    <div className="form-group">
                        <label>Name</label>
                        <input
                            type="text"
                            className="form-control"
                            placeholder="Input yor name"
                            required=""
                            ref={nicknameRef}
                        />
                    </div>
                    <div className="form-group">
                        <label>Title</label>
                        <input
                            type="text"
                            className="form-control"
                            placeholder="제목을 입력하세요"
                            required=""
                            ref={titleRef}
                        />
                    </div>
                    <div className="form-group">
                        <label>Content</label>
                        <textarea
                            className="form-control"
                            placeholder="내용을 입력하세요"
                            rows={10}
                            ref={contentRef}
                        />
                    </div>
                    <div className="form-group">
                        <label>password</label>
                        <input
                            type="password"
                            className="form-control"
                            placeholder="설정할 바말번호를 입력하세요"
                        />
                    </div>
                    <div className="file-field">
                        <div className="btn btn-primary btn-sm float-left " id="fileZone">
                            <input type="file" />
                        </div>
                    </div>
                    <br />
                    <br />
                    <Button variant="primary" onClick={addArticle}>Submit</Button>
                    <Button type="reset" variant="warning">Cancel</Button>
                </div>
            </Form>
        </>
    )
}